package com.example.LoginPlusSecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginPlusSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
